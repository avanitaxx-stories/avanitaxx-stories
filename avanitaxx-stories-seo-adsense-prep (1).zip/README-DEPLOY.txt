AVANITAXX STORIES — SEO / ADSENSE PREPARATION

Files:
- index.html: updated copy of the supplied November 9, 2026 source file.
- about.html
- privacy-policy.html
- terms-and-conditions.html
- cookie-policy.html

Deployment:
1. Back up the current repository/index.html.
2. Upload/commit all five HTML files to the repository's existing GitHub Pages publishing root.
3. Keep existing assets, manifest, service worker, and all other project files in place.
4. Test the four legal URLs directly after GitHub Pages deploys:
   /avanitaxx-stories/about.html
   /avanitaxx-stories/privacy-policy.html
   /avanitaxx-stories/terms-and-conditions.html
   /avanitaxx-stories/cookie-policy.html

Intentionally deferred:
- Sitemap and final canonical/OG/schema domain migration: do this after the custom domain is connected and verified. Current URLs remain on the existing GitHub Pages domain.
- AdSense verification token: paste only the exact meta tag supplied by Google into the marked <head> insertion point.
- Sponsored ad units: keep the existing sponsored containers hidden until Google approval and actual publisher/ad-unit code are available. Never use placeholder ad code.

Preservation:
- No Supabase schema, credentials, authentication flow, story/chapter data, reader interactions, profile, chat, Notes, Storage, Realtime, or Edge Function logic was intentionally changed.
- Existing in-app policy modal data remains available; footer and cookie notice links now navigate to crawlable standalone policy pages.
